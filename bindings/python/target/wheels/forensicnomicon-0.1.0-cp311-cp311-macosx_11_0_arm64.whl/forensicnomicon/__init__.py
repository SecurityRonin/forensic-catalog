from .forensicnomicon import *

__doc__ = forensicnomicon.__doc__
if hasattr(forensicnomicon, "__all__"):
    __all__ = forensicnomicon.__all__